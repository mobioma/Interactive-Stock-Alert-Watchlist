# 🚀 NGX WATCHLIST — DEPLOY GUIDE
## From your laptop to live on your phone in ~25 minutes. Completely free.

---

## WHAT YOU'LL NEED
- A laptop (Windows or Mac)
- Your phone
- A free GitHub account → github.com
- A free Render account → render.com
- The app folder I gave you (ngx-alert-app)

---

## STEP 1 — Install Node.js on your laptop (5 min)

1. Go to: https://nodejs.org
2. Download the "LTS" version (big green button)
3. Install it (just click Next through everything)
4. Open your Terminal (Mac) or Command Prompt (Windows)
5. Type: `node --version`
6. If you see a number like "v20.x.x" — you're good ✅

---

## STEP 2 — Generate your VAPID keys (2 min)
These are secret keys that make push notifications work.

In your Terminal, type these one at a time:
```
npm install -g web-push
web-push generate-vapid-keys
```

You'll see something like:
```
Public Key: BFX8abc123....(long string)
Private Key: xyz789....(long string)
```

COPY BOTH KEYS AND SAVE THEM IN NOTES. You'll need them in Step 5.

---

## STEP 3 — Put the app on GitHub (5 min)

1. Go to github.com → Sign up for a free account
2. Click the green "New" button to create a repository
3. Name it: ngx-watchlist
4. Click "Create repository"
5. Follow GitHub's instructions to upload the ngx-alert-app folder

OR if you have Git installed, in Terminal:
```
cd ngx-alert-app
git init
git add .
git commit -m "NGX Watchlist app"
git remote add origin https://github.com/YOUR_USERNAME/ngx-watchlist.git
git push -u origin main
```

---

## STEP 4 — Deploy to Render (5 min)
Render is a free server host. Your app will run here 24/7.

1. Go to: https://render.com
2. Sign up with your GitHub account
3. Click "New +" → "Web Service"
4. Connect your GitHub repository (ngx-watchlist)
5. Fill in these settings:
   - Name: ngx-watchlist
   - Runtime: Node
   - Build Command: `npm install`
   - Start Command: `node server.js`
   - Instance Type: Free ✅

6. Click "Create Web Service"

Wait ~2 minutes for it to deploy. You'll get a URL like:
`https://ngx-watchlist.onrender.com`

---

## STEP 5 — Add your VAPID keys as environment variables (3 min)
This is what enables push notifications.

1. In Render, go to your service
2. Click "Environment" in the left menu
3. Add these 3 variables:

| Key | Value |
|-----|-------|
| VAPID_PUBLIC_KEY | (your public key from Step 2) |
| VAPID_PRIVATE_KEY | (your private key from Step 2) |
| VAPID_EMAIL | mailto:youremail@gmail.com |

4. Click "Save Changes"
5. Render will automatically restart with push notifications enabled ✅

---

## STEP 6 — Open on your phone and enable alerts (2 min)

1. On your phone, open Safari (iPhone) or Chrome (Android)
2. Go to your Render URL: https://ngx-watchlist.onrender.com
3. Tap the "🔔 Enable Alerts" button at the top
4. When your phone asks "Allow notifications?" → tap ALLOW
5. You'll see "🔔 Alerts Active" — you're done! ✅

**To install as an app on your home screen:**
- iPhone: tap the Share button → "Add to Home Screen"
- Android: tap the 3-dot menu → "Add to Home Screen"

Now it lives on your phone like a real app.

---

## STEP 7 — Update prices manually (ongoing)

The app auto-checks prices every 30 minutes during NGX trading hours
(Mon-Fri, 10:00 AM - 2:30 PM Lagos time = 3:00 AM - 7:30 AM Winnipeg).

To manually update a stock price:
1. Open the app
2. Tap ✏️ Edit on any stock card
3. Update the Current Price field
4. Save — the app instantly checks if it's in your buy zone
5. If YES → push notification fires to your phone with your full thesis

---

## HOW ALERTS WORK

When a stock hits your buy zone:
1. 📲 Your phone gets a push notification — even if the app is closed
2. The notification shows: stock name, current price, buy zone, target price, upside %
3. Tap the notification → opens the app → full thesis, metrics, and stop-loss visible
4. Tap "📈 Chart" → opens TradingView directly
5. Place your limit order through your broker

---

## TROUBLESHOOTING

**App won't load:**
- Free Render instances "sleep" after 15 min of no activity
- First load may take 30-60 seconds to wake up
- This is normal on the free plan

**No push notifications:**
- Make sure you tapped "Enable Alerts" in the app
- Make sure you allowed notifications when prompted
- Check that the VAPID keys are set correctly in Render environment variables

**Prices not updating automatically:**
- Auto-update only works during NGX trading hours (Mon-Fri 10AM-2:30PM Lagos)
- You can always tap "Check Now" to force an update
- Yahoo Finance NGX data may have a 15-minute delay

---

## COSTS
- GitHub: FREE ✅
- Render (free tier): FREE ✅
- Push notifications: FREE ✅
- Total monthly cost: ₦0 / $0 CAD

---

## NEED HELP?
If you get stuck on any step, take a screenshot and bring it to Claude.
I'll walk you through it.

Your app URL will be: https://ngx-watchlist.onrender.com
(or whatever name you chose on Render)
